-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.15-log - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             8.3.0.4694
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for tokoemas
CREATE DATABASE IF NOT EXISTS `tokoemas` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `tokoemas`;


-- Dumping structure for table tokoemas.tm_barang
CREATE TABLE IF NOT EXISTS `tm_barang` (
  `kode_barcode` varchar(8) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  `kode_kategori` varchar(50) NOT NULL,
  `kode_jenis` varchar(50) NOT NULL,
  `kode_gudang` varchar(20) NOT NULL,
  `kode_intern` varchar(20) NOT NULL,
  `kadar` varchar(20) NOT NULL,
  `berat` double NOT NULL,
  `berat_asli` double NOT NULL,
  `nilai_pokok` double unsigned NOT NULL,
  `harga_jual` double NOT NULL,
  `status_barang` varchar(30) NOT NULL,
  `barcode_date` datetime NOT NULL,
  `barcode_by` varchar(20) NOT NULL,
  `deleted_date` datetime NOT NULL,
  `deleted_by` varchar(20) NOT NULL,
  `sold_date` datetime NOT NULL,
  `sold_by` varchar(20) NOT NULL,
  PRIMARY KEY (`kode_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table tokoemas.tm_barang: ~0 rows (approximately)
DELETE FROM `tm_barang`;
/*!40000 ALTER TABLE `tm_barang` DISABLE KEYS */;
INSERT INTO `tm_barang` (`kode_barcode`, `nama_barang`, `keterangan`, `kode_kategori`, `kode_jenis`, `kode_gudang`, `kode_intern`, `kadar`, `berat`, `berat_asli`, `nilai_pokok`, `harga_jual`, `status_barang`, `barcode_date`, `barcode_by`, `deleted_date`, `deleted_by`, `sold_date`, `sold_by`) VALUES
	('10000001', 'cc mt 1', '', 'MT', 'CCMT', 'NP01', '750', '750', 1.2, 1.2, 480000, 540000, 'Terjual', '2021-02-21 08:35:52', 'user', '2000-01-01 00:00:00', '-', '2021-02-21 08:42:07', 'Dwi'),
	('10000002', 'cc mt 2', '', 'MT', 'CCMT', 'NP01', '750', '750', 1.8, 1.8, 720000, 810000, 'Terjual', '2021-02-21 08:36:09', 'user', '2000-01-01 00:00:00', '-', '2021-02-21 08:42:20', 'Fera'),
	('10000003', 'kl mt 1', '', 'MT', 'KLMT', 'NP01', '75', '75', 3.9, 3.9, 1560000, 1755000, 'Terjual', '2021-02-21 08:37:39', 'user', '2000-01-01 00:00:00', '-', '2021-02-21 08:42:27', 'Luluk'),
	('10000004', 'kl mt 2', '', 'MT', 'KLMT', 'NP01', '750', '750', 4.1, 4.1, 1640000, 1845000, 'Terjual', '2021-02-21 08:37:54', 'user', '2000-01-01 00:00:00', '-', '2021-02-21 08:42:07', 'Dwi'),
	('10000005', 'kl mt 3', '', 'MT', 'KLMT', 'BAKI BARCODE', '750', '750', 4, 4, 1600000, 1800000, 'Hancur', '2021-02-21 08:38:06', 'user', '2021-02-21 08:38:55', 'user', '2000-01-01 00:00:00', '-');
/*!40000 ALTER TABLE `tm_barang` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tm_bunga_gadai
CREATE TABLE IF NOT EXISTS `tm_bunga_gadai` (
  `min` double NOT NULL,
  `max` double NOT NULL,
  `bunga` double DEFAULT NULL,
  PRIMARY KEY (`min`,`max`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_bunga_gadai: ~4 rows (approximately)
DELETE FROM `tm_bunga_gadai`;
/*!40000 ALTER TABLE `tm_bunga_gadai` DISABLE KEYS */;
INSERT INTO `tm_bunga_gadai` (`min`, `max`, `bunga`) VALUES
	(0, 500000, 4),
	(500001, 5000000, 3),
	(5000001, 10000000, 2.5),
	(10000001, 100000000, 2);
/*!40000 ALTER TABLE `tm_bunga_gadai` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tm_gadai_detail
CREATE TABLE IF NOT EXISTS `tm_gadai_detail` (
  `no_gadai` varchar(50) NOT NULL,
  `no_urut` int(11) NOT NULL,
  `kode_kategori` varchar(50) DEFAULT NULL,
  `nama_barang` varchar(50) DEFAULT NULL,
  `berat` double DEFAULT NULL,
  `nilai_jual` double DEFAULT NULL,
  `nilai_jual_sekarang` double DEFAULT NULL,
  PRIMARY KEY (`no_gadai`,`no_urut`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_gadai_detail: ~0 rows (approximately)
DELETE FROM `tm_gadai_detail`;
/*!40000 ALTER TABLE `tm_gadai_detail` DISABLE KEYS */;
INSERT INTO `tm_gadai_detail` (`no_gadai`, `no_urut`, `kode_kategori`, `nama_barang`, `berat`, `nilai_jual`, `nilai_jual_sekarang`) VALUES
	('0001', 1, 'MD', 'tes', 3, 630000, 630000),
	('0002', 1, 'MD', 'tes', 3, 630000, 630000),
	('PT-210221-0001', 1, 'MT', 'kl mt', 3, 1350000, 1350000),
	('PT-210221-0002', 1, 'MT', 'kl mt', 3, 1350000, 1350000),
	('PT-210221-0003', 1, 'MDS', 'cc', 1.5, 405000, 405000),
	('PT-210221-0004', 1, 'MDS', 'cc', 1.5, 405000, 405000);
/*!40000 ALTER TABLE `tm_gadai_detail` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tm_gadai_head
CREATE TABLE IF NOT EXISTS `tm_gadai_head` (
  `no_gadai` varchar(50) NOT NULL DEFAULT '',
  `tgl_gadai` datetime DEFAULT NULL,
  `kode_sales` varchar(50) DEFAULT NULL,
  `kode_pelanggan` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `no_telp` varchar(50) DEFAULT NULL,
  `keterangan` varchar(500) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `total_pinjaman` double DEFAULT NULL,
  `lama_pinjam` int(11) DEFAULT NULL,
  `bunga_persen` double DEFAULT NULL,
  `bunga_komp` double DEFAULT NULL,
  `bunga_rp` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `tgl_lunas` datetime DEFAULT NULL,
  `sales_lunas` varchar(50) DEFAULT NULL,
  `user_lunas` varchar(50) DEFAULT NULL,
  `tgl_batal` datetime DEFAULT NULL,
  `sales_batal` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_gadai`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table tokoemas.tm_gadai_head: ~1 rows (approximately)
DELETE FROM `tm_gadai_head`;
/*!40000 ALTER TABLE `tm_gadai_head` DISABLE KEYS */;
INSERT INTO `tm_gadai_head` (`no_gadai`, `tgl_gadai`, `kode_sales`, `kode_pelanggan`, `nama`, `alamat`, `no_telp`, `keterangan`, `total_berat`, `total_pinjaman`, `lama_pinjam`, `bunga_persen`, `bunga_komp`, `bunga_rp`, `kode_user`, `status`, `tgl_lunas`, `sales_lunas`, `user_lunas`, `tgl_batal`, `sales_batal`) VALUES
	('0001', '2021-02-21 09:40:20', 'Dwi', '', '', '', '', '', 3, 441000, 0, 4, 0, 0, 'user', 'Lunas', '2021-02-21 09:40:48', 'Fera', 'user', '2000-01-01 00:00:00', ''),
	('0002', '2021-02-21 09:40:48', 'Fera', '', '', '', '', 'No Hutang Lama : 0001\nPinjaman : 441,000\nCicil Pinjaman : 41,000\nBunga Dibayar : 0', 3, 400000, 0, 4, 0, 0, 'user', 'Belum Lunas', '2000-01-01 00:00:00', '', '', '2000-01-01 00:00:00', ''),
	('PT-210221-0001', '2021-02-21 09:03:12', 'Dwi', '', '', '', '', '', 3, 945000, 0, 3, 0, 5000, 'user', 'Lunas', '2021-02-21 09:03:41', 'Fera', 'user', '2021-02-21 09:12:44', 'user'),
	('PT-210221-0002', '2021-02-21 09:03:41', 'Fera', '', '', '', '', 'No Hutang Lama : PT-210221-0001\nPinjaman : 945,000\nCicil Pinjaman : 445,000\nBunga Dibayar : 5,000', 3, 500000, 0, 4, 0, 0, 'user', 'Belum Lunas', '2000-01-01 00:00:00', '', NULL, '2000-01-01 00:00:00', ''),
	('PT-210221-0003', '2021-02-21 09:07:59', 'Nurul', '', '', '', '', '', 1.5, 283500, 0, 4, 0, 0, 'user', 'Belum Lunas', '2000-01-01 00:00:00', '', 'user', '2000-01-01 00:00:00', ''),
	('PT-210221-0004', '2021-02-21 09:08:18', 'Nurul', '', '', '', '', 'No Hutang Lama : PT-210221-0003\nPinjaman : 283,500\nCicil Pinjaman : 0\nBunga Dibayar : 1,000', 1.5, 283500, 0, 4, 0, 0, 'user', 'Batal Gadai', '2000-01-01 00:00:00', '', '', '2021-02-21 09:12:10', 'user');
/*!40000 ALTER TABLE `tm_gadai_head` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tm_gudang
CREATE TABLE IF NOT EXISTS `tm_gudang` (
  `kode_gudang` varchar(50) NOT NULL,
  `berat_baki` double DEFAULT NULL,
  PRIMARY KEY (`kode_gudang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_gudang: ~37 rows (approximately)
DELETE FROM `tm_gudang`;
/*!40000 ALTER TABLE `tm_gudang` DISABLE KEYS */;
INSERT INTO `tm_gudang` (`kode_gudang`, `berat_baki`) VALUES
	('BAKI BARCODE', 0),
	('BAKI BARCODE 2', 0),
	('BAKI BARCODE 3', 0),
	('NP01', 397.69),
	('NP02', 368.05),
	('NP03', 384.14),
	('NP04', 369.18),
	('NP05', 717.87),
	('NP06', 375),
	('NP07', 379.34),
	('NP08', 310.23),
	('NP09', 386.1),
	('NP10', 842.7),
	('NP11', 407.2),
	('NP12', 410.8),
	('NP13', 428.3),
	('NP14', 410.8),
	('NP15', 100.34),
	('NP17', 74.5),
	('NP18', 101.9),
	('NP19', 57.36),
	('NP20', 220.05),
	('NP21', 227.51),
	('NP23', 98.98),
	('NP24', 326.79),
	('NP25', 302.52),
	('NP27', 146.3),
	('NP28', 70.09),
	('NP31', 60.87),
	('NP34', 88.56),
	('PTSK19', 58.03),
	('PTSK20', 220.14),
	('PTSK22', 96.75),
	('PTSK26', 61.62),
	('PTSK30', 101.86),
	('PTSK31', 63.43),
	('PTSK33', 72.14);
/*!40000 ALTER TABLE `tm_gudang` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tm_jenis
CREATE TABLE IF NOT EXISTS `tm_jenis` (
  `kode_jenis` varchar(20) NOT NULL,
  `nama_jenis` varchar(50) NOT NULL,
  `kode_kategori` varchar(20) NOT NULL,
  PRIMARY KEY (`kode_jenis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_jenis: ~22 rows (approximately)
DELETE FROM `tm_jenis`;
/*!40000 ALTER TABLE `tm_jenis` DISABLE KEYS */;
INSERT INTO `tm_jenis` (`kode_jenis`, `nama_jenis`, `kode_kategori`) VALUES
	('ATMD', 'anting md', 'MD'),
	('ATMDS', 'anting mds', 'MDS'),
	('ATMT', 'anting mt', 'MT'),
	('CCINTEN', 'cincin inten', 'INTEN'),
	('CCMD', 'cincin md', 'MD'),
	('CCMDS', 'cincin mds', 'MDS'),
	('CCMT', 'cincin mt', 'MT'),
	('GLINTEN', 'gelang inten', 'INTEN'),
	('GLMD', 'gelang md', 'MD'),
	('GLMDS', 'gelang mds', 'MDS'),
	('GLMT', 'gelang mt', 'MT'),
	('KLMD', 'kalung md', 'MD'),
	('KLMDS', 'kalung mds', 'MDS'),
	('KLMT', 'kalung mt', 'MT'),
	('MNINTEN', 'mainan inten', 'INTEN'),
	('MNMD', 'mainan md', 'MD'),
	('MNMDS', 'mainan mds', 'MDS'),
	('MNMT', 'mainan mt', 'MT'),
	('TDINTEN', 'tindik inten', 'INTEN'),
	('TDMD', 'tindik md', 'MD'),
	('TDMDS', 'tindik mds', 'MDS'),
	('TDMT', 'tindik mt', 'MT');
/*!40000 ALTER TABLE `tm_jenis` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tm_kategori
CREATE TABLE IF NOT EXISTS `tm_kategori` (
  `kode_kategori` varchar(20) NOT NULL,
  `nama_kategori` varchar(50) NOT NULL,
  `harga_beli` double NOT NULL,
  `harga_jual` double NOT NULL,
  PRIMARY KEY (`kode_kategori`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table tokoemas.tm_kategori: ~7 rows (approximately)
DELETE FROM `tm_kategori`;
/*!40000 ALTER TABLE `tm_kategori` DISABLE KEYS */;
INSERT INTO `tm_kategori` (`kode_kategori`, `nama_kategori`, `harga_beli`, `harga_jual`) VALUES
	('INTEN', 'inten md', 200000, 500000),
	('MD', 'emas muda', 190000, 210000),
	('MDS', 'emas tengahan', 260000, 270000),
	('MT', 'emas tua', 400000, 450000),
	('MT87', 'MT87', 450000, 525000),
	('MT916', 'MT916', 550000, 650000),
	('MT99', 'MT99', 575000, 675000);
/*!40000 ALTER TABLE `tm_kategori` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tm_kategori_transaksi
CREATE TABLE IF NOT EXISTS `tm_kategori_transaksi` (
  `kode_kategori` varchar(50) NOT NULL,
  `jenis_transaksi` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`kode_kategori`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_kategori_transaksi: ~5 rows (approximately)
DELETE FROM `tm_kategori_transaksi`;
/*!40000 ALTER TABLE `tm_kategori_transaksi` DISABLE KEYS */;
INSERT INTO `tm_kategori_transaksi` (`kode_kategori`, `jenis_transaksi`) VALUES
	('BEBAN GAJI', 'K'),
	('BEBAN OPERASIONAL', 'K'),
	('PEMBELIAN SUPPLIER', 'K'),
	('PENDAPATAN LAIN-LAIN', 'D'),
	('TAMBAH MODAL', 'D');
/*!40000 ALTER TABLE `tm_kategori_transaksi` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tm_log_harga
CREATE TABLE IF NOT EXISTS `tm_log_harga` (
  `tanggal` datetime NOT NULL,
  `kode_kategori` varchar(20) NOT NULL,
  `harga_beli` double NOT NULL,
  `harga_jual` double NOT NULL,
  `user` varchar(50) NOT NULL,
  PRIMARY KEY (`tanggal`,`kode_kategori`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_log_harga: ~0 rows (approximately)
DELETE FROM `tm_log_harga`;
/*!40000 ALTER TABLE `tm_log_harga` DISABLE KEYS */;
/*!40000 ALTER TABLE `tm_log_harga` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tm_otoritas
CREATE TABLE IF NOT EXISTS `tm_otoritas` (
  `username` varchar(50) NOT NULL,
  `jenis` varchar(50) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`username`,`jenis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_otoritas: ~46 rows (approximately)
DELETE FROM `tm_otoritas`;
/*!40000 ALTER TABLE `tm_otoritas` DISABLE KEYS */;
INSERT INTO `tm_otoritas` (`username`, `jenis`, `status`) VALUES
	('kasir', 'Ambil Barang', 'false'),
	('kasir', 'Barcode Barang', 'false'),
	('kasir', 'Data Pelanggan', 'true'),
	('kasir', 'Data Pelunasan Gadai', 'false'),
	('kasir', 'Data Pembelian', 'true'),
	('kasir', 'Data Penjualan', 'true'),
	('kasir', 'Data Sales', 'false'),
	('kasir', 'Data Terima Gadai', 'true'),
	('kasir', 'Detail Barang Barcode', 'false'),
	('kasir', 'Keuangan', 'false'),
	('kasir', 'Laporan Barang', 'false'),
	('kasir', 'Laporan Gadai', 'false'),
	('kasir', 'Laporan Keuangan', 'false'),
	('kasir', 'Laporan Pembelian', 'false'),
	('kasir', 'Laporan Penjualan', 'false'),
	('kasir', 'Pelunasan Gadai', 'false'),
	('kasir', 'Pembelian Baru', 'true'),
	('kasir', 'Pengaturan Umum', 'false'),
	('kasir', 'Penjualan Baru', 'true'),
	('kasir', 'Stok Barang Barcode', 'false'),
	('kasir', 'Stok Barang Dalam', 'false'),
	('kasir', 'Tambah Barang', 'false'),
	('kasir', 'Terima Gadai', 'true'),
	('user', 'Ambil Barang', 'true'),
	('user', 'Barcode Barang', 'true'),
	('user', 'Data Pelanggan', 'true'),
	('user', 'Data Pelunasan Gadai', 'true'),
	('user', 'Data Pembelian', 'true'),
	('user', 'Data Penjualan', 'true'),
	('user', 'Data Sales', 'true'),
	('user', 'Data Terima Gadai', 'true'),
	('user', 'Detail Barang Barcode', 'true'),
	('user', 'Keuangan', 'true'),
	('user', 'Laporan Barang', 'true'),
	('user', 'Laporan Gadai', 'true'),
	('user', 'Laporan Keuangan', 'true'),
	('user', 'Laporan Pembelian', 'true'),
	('user', 'Laporan Penjualan', 'true'),
	('user', 'Pelunasan Gadai', 'true'),
	('user', 'Pembelian Baru', 'true'),
	('user', 'Pengaturan Umum', 'true'),
	('user', 'Penjualan Baru', 'true'),
	('user', 'Stok Barang Barcode', 'true'),
	('user', 'Stok Barang Dalam', 'true'),
	('user', 'Tambah Barang', 'true'),
	('user', 'Terima Gadai', 'true');
/*!40000 ALTER TABLE `tm_otoritas` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tm_pelanggan
CREATE TABLE IF NOT EXISTS `tm_pelanggan` (
  `kode_pelanggan` varchar(50) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `no_telp` varchar(20) DEFAULT NULL,
  `no_handphone` varchar(50) DEFAULT NULL,
  `keterangan` varchar(500) DEFAULT NULL,
  `identitas` varchar(50) DEFAULT NULL,
  `no_identitas` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`kode_pelanggan`),
  UNIQUE KEY `Index 2` (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_pelanggan: ~1 rows (approximately)
DELETE FROM `tm_pelanggan`;
/*!40000 ALTER TABLE `tm_pelanggan` DISABLE KEYS */;
INSERT INTO `tm_pelanggan` (`kode_pelanggan`, `nama`, `alamat`, `no_telp`, `no_handphone`, `keterangan`, `identitas`, `no_identitas`, `status`) VALUES
	('CS-00001', 'tes', 'tes', '', '', '', '', '', 'true');
/*!40000 ALTER TABLE `tm_pelanggan` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tm_sales
CREATE TABLE IF NOT EXISTS `tm_sales` (
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(500) DEFAULT NULL,
  `no_telp` varchar(50) DEFAULT NULL,
  `no_handphone` varchar(50) DEFAULT NULL,
  `keterangan` varchar(50) DEFAULT NULL,
  `identitas` varchar(50) DEFAULT NULL,
  `no_identitas` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_sales: ~5 rows (approximately)
DELETE FROM `tm_sales`;
/*!40000 ALTER TABLE `tm_sales` DISABLE KEYS */;
INSERT INTO `tm_sales` (`nama`, `alamat`, `no_telp`, `no_handphone`, `keterangan`, `identitas`, `no_identitas`, `status`) VALUES
	('Dwi', '', '', '', '', '', '', 'true'),
	('Fera', '', '', '', '', '', '', 'true'),
	('Luluk', '', '', '', '', '', '', 'true'),
	('Murni', '', '', '', '', '', '', 'true'),
	('Nurul', '', '', '', '', '', '', 'true');
/*!40000 ALTER TABLE `tm_sales` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tm_system
CREATE TABLE IF NOT EXISTS `tm_system` (
  `nama_toko` varchar(50) DEFAULT NULL,
  `alamat_toko` varchar(50) DEFAULT NULL,
  `no_telp_toko` varchar(50) DEFAULT NULL,
  `prefix_barcode` varchar(50) DEFAULT NULL,
  `berat_label` double DEFAULT NULL,
  `tgl_system` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tm_system: ~1 rows (approximately)
DELETE FROM `tm_system`;
/*!40000 ALTER TABLE `tm_system` DISABLE KEYS */;
INSERT INTO `tm_system` (`nama_toko`, `alamat_toko`, `no_telp_toko`, `prefix_barcode`, `berat_label`, `tgl_system`) VALUES
	('Toko Emas Gunung Emas', 'a', '1', '1', 0.05, '2021-02-21');
/*!40000 ALTER TABLE `tm_system` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tm_user
CREATE TABLE IF NOT EXISTS `tm_user` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `level` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_user: ~2 rows (approximately)
DELETE FROM `tm_user`;
/*!40000 ALTER TABLE `tm_user` DISABLE KEYS */;
INSERT INTO `tm_user` (`username`, `password`, `level`) VALUES
	('kasir', 'kasir', 'Sales'),
	('user', 'user', 'Admin');
/*!40000 ALTER TABLE `tm_user` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tm_verifikasi
CREATE TABLE IF NOT EXISTS `tm_verifikasi` (
  `username` varchar(50) NOT NULL,
  `jenis` varchar(50) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`username`,`jenis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_verifikasi: ~29 rows (approximately)
DELETE FROM `tm_verifikasi`;
/*!40000 ALTER TABLE `tm_verifikasi` DISABLE KEYS */;
INSERT INTO `tm_verifikasi` (`username`, `jenis`, `status`) VALUES
	('kasir', 'Ambil Barang', 'false'),
	('kasir', 'Batal Keuangan', 'false'),
	('kasir', 'Batal Pelunasan Gadai', 'false'),
	('kasir', 'Batal Pembelian', 'false'),
	('kasir', 'Batal Penjualan', 'false'),
	('kasir', 'Batal Terima Gadai', 'false'),
	('kasir', 'Hancur Barang', 'false'),
	('kasir', 'Pelunasan Gadai', 'false'),
	('kasir', 'Pembelian', 'false'),
	('kasir', 'Penjualan', 'false'),
	('kasir', 'Tambah Barang', 'false'),
	('kasir', 'Terima Gadai', 'false'),
	('kasir', 'Ubah Berat Gadai', 'false'),
	('user', 'Ambil Barang', 'true'),
	('user', 'Batal Keuangan', 'true'),
	('user', 'Batal Pelunasan Gadai', 'true'),
	('user', 'Batal Pembelian', 'true'),
	('user', 'Batal Penjualan', 'true'),
	('user', 'Batal Terima Gadai', 'true'),
	('user', 'Edit Barang', 'true'),
	('user', 'Export Barang', 'true'),
	('user', 'Hancur Barang', 'true'),
	('user', 'Import Barang', 'true'),
	('user', 'Pelunasan Gadai', 'true'),
	('user', 'Pembelian', 'true'),
	('user', 'Penjualan', 'true'),
	('user', 'Tambah Barang', 'true'),
	('user', 'Terima Gadai', 'true'),
	('user', 'Ubah Berat Gadai', 'true');
/*!40000 ALTER TABLE `tm_verifikasi` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_ambil_barang_detail
CREATE TABLE IF NOT EXISTS `tt_ambil_barang_detail` (
  `no_ambil` varchar(50) NOT NULL,
  `no_urut` int(11) NOT NULL,
  `kode_kategori` varchar(50) DEFAULT NULL,
  `kode_jenis` varchar(50) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `berat` double DEFAULT NULL,
  PRIMARY KEY (`no_ambil`,`no_urut`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_ambil_barang_detail: ~1 rows (approximately)
DELETE FROM `tt_ambil_barang_detail`;
/*!40000 ALTER TABLE `tt_ambil_barang_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_ambil_barang_detail` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_ambil_barang_head
CREATE TABLE IF NOT EXISTS `tt_ambil_barang_head` (
  `no_ambil` varchar(50) NOT NULL,
  `tgl_ambil` datetime DEFAULT NULL,
  `keterangan` varchar(50) DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_ambil`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_ambil_barang_head: ~1 rows (approximately)
DELETE FROM `tt_ambil_barang_head`;
/*!40000 ALTER TABLE `tt_ambil_barang_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_ambil_barang_head` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_cetak_barcode_detail
CREATE TABLE IF NOT EXISTS `tt_cetak_barcode_detail` (
  `no_cetak` varchar(50) NOT NULL,
  `kode_barcode` varchar(50) NOT NULL,
  PRIMARY KEY (`no_cetak`,`kode_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_cetak_barcode_detail: ~2 rows (approximately)
DELETE FROM `tt_cetak_barcode_detail`;
/*!40000 ALTER TABLE `tt_cetak_barcode_detail` DISABLE KEYS */;
INSERT INTO `tt_cetak_barcode_detail` (`no_cetak`, `kode_barcode`) VALUES
	('CB-210220-0001', '00000003'),
	('CB-210220-0001', '10000001'),
	('CB-210221-0001', '10000001'),
	('CB-210221-0001', '10000002'),
	('CB-210221-0001', '10000003'),
	('CB-210221-0001', '10000004'),
	('CB-210221-0001', '10000005');
/*!40000 ALTER TABLE `tt_cetak_barcode_detail` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_cetak_barcode_head
CREATE TABLE IF NOT EXISTS `tt_cetak_barcode_head` (
  `no_cetak` varchar(50) NOT NULL,
  `tgl_cetak` datetime DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `total_berat_asli` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_cetak`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_cetak_barcode_head: ~1 rows (approximately)
DELETE FROM `tt_cetak_barcode_head`;
/*!40000 ALTER TABLE `tt_cetak_barcode_head` DISABLE KEYS */;
INSERT INTO `tt_cetak_barcode_head` (`no_cetak`, `tgl_cetak`, `total_qty`, `total_berat`, `total_berat_asli`, `kode_user`) VALUES
	('CB-210220-0001', '2021-02-20 23:40:25', 2, 7.5, 27, 'Dwi'),
	('CB-210221-0001', '2021-02-21 08:38:34', 5, 15, 15, 'user');
/*!40000 ALTER TABLE `tt_cetak_barcode_head` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_hancur_detail
CREATE TABLE IF NOT EXISTS `tt_hancur_detail` (
  `no_hancur` varchar(50) NOT NULL,
  `kode_barcode` varchar(50) NOT NULL,
  PRIMARY KEY (`no_hancur`,`kode_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_hancur_detail: ~1 rows (approximately)
DELETE FROM `tt_hancur_detail`;
/*!40000 ALTER TABLE `tt_hancur_detail` DISABLE KEYS */;
INSERT INTO `tt_hancur_detail` (`no_hancur`, `kode_barcode`) VALUES
	('HB-210220-0001', '10000001'),
	('HB-210221-0001', '10000005');
/*!40000 ALTER TABLE `tt_hancur_detail` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_hancur_head
CREATE TABLE IF NOT EXISTS `tt_hancur_head` (
  `no_hancur` varchar(50) NOT NULL,
  `tgl_hancur` datetime DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `total_berat_asli` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_hancur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_hancur_head: ~1 rows (approximately)
DELETE FROM `tt_hancur_head`;
/*!40000 ALTER TABLE `tt_hancur_head` DISABLE KEYS */;
INSERT INTO `tt_hancur_head` (`no_hancur`, `tgl_hancur`, `total_qty`, `total_berat`, `total_berat_asli`, `kode_user`) VALUES
	('HB-210220-0001', '2021-02-20 23:56:00', 1, 5.5, 5, 'user'),
	('HB-210221-0001', '2021-02-21 08:38:55', 1, 4, 4, 'user');
/*!40000 ALTER TABLE `tt_hancur_head` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_keuangan
CREATE TABLE IF NOT EXISTS `tt_keuangan` (
  `no_keuangan` varchar(50) NOT NULL,
  `tgl_keuangan` datetime DEFAULT NULL,
  `kategori` varchar(50) DEFAULT NULL,
  `keterangan` varchar(500) DEFAULT NULL,
  `jumlah_rp` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_keuangan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tt_keuangan: ~0 rows (approximately)
DELETE FROM `tt_keuangan`;
/*!40000 ALTER TABLE `tt_keuangan` DISABLE KEYS */;
INSERT INTO `tt_keuangan` (`no_keuangan`, `tgl_keuangan`, `kategori`, `keterangan`, `jumlah_rp`, `kode_user`) VALUES
	('KK-210221-0001', '2021-02-21 08:42:07', 'Penjualan', 'PJ-210221-0001', 2385000, 'Dwi'),
	('KK-210221-0002', '2021-02-21 08:42:20', 'Penjualan', 'PJ-210221-0002', 810000, 'Fera'),
	('KK-210221-0003', '2021-02-21 08:42:27', 'Penjualan', 'PJ-210221-0003', 1755000, 'Luluk'),
	('KK-210221-0005', '2021-02-21 08:42:56', 'Pembelian', 'PB-210221-0002', -1560000, 'Nurul'),
	('KK-210221-0006', '2021-02-21 09:03:12', 'Terima Gadai', 'PT-210221-0001', -945000, 'Dwi'),
	('KK-210221-0007', '2021-02-21 09:03:41', 'Pelunasan Gadai', 'PT-210221-0001', 945000, 'Fera'),
	('KK-210221-0008', '2021-02-21 09:03:41', 'Bunga Gadai', 'PT-210221-0001', 5000, 'Fera'),
	('KK-210221-0009', '2021-02-21 09:03:41', 'Terima Gadai', 'PT-210221-0002', -500000, 'Fera'),
	('KK-210221-0010', '2021-02-21 09:07:59', 'Terima Gadai', 'PT-210221-0003', -283500, 'Nurul'),
	('KK-210221-0019', '2021-02-21 09:40:20', 'Terima Gadai', '0001', -441000, 'Dwi'),
	('KK-210221-0020', '2021-02-21 09:40:48', 'Pelunasan Gadai', '0001', 441000, 'Fera'),
	('KK-210221-0021', '2021-02-21 09:40:48', 'Bunga Gadai', '0001', 0, 'Fera'),
	('KK-210221-0022', '2021-02-21 09:40:48', 'Terima Gadai', '0002', -400000, 'Fera');
/*!40000 ALTER TABLE `tt_keuangan` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_pembelian_detail
CREATE TABLE IF NOT EXISTS `tt_pembelian_detail` (
  `no_pembelian` varchar(50) NOT NULL,
  `no_urut` int(11) NOT NULL,
  `kode_kategori` varchar(50) DEFAULT NULL,
  `kode_jenis` varchar(50) DEFAULT NULL,
  `nama_barang` varchar(50) DEFAULT NULL,
  `berat_kotor` double DEFAULT NULL,
  `berat_bersih` double DEFAULT NULL,
  `harga_komp` double DEFAULT NULL,
  `harga_beli` double DEFAULT NULL,
  PRIMARY KEY (`no_pembelian`,`no_urut`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tt_pembelian_detail: ~0 rows (approximately)
DELETE FROM `tt_pembelian_detail`;
/*!40000 ALTER TABLE `tt_pembelian_detail` DISABLE KEYS */;
INSERT INTO `tt_pembelian_detail` (`no_pembelian`, `no_urut`, `kode_kategori`, `kode_jenis`, `nama_barang`, `berat_kotor`, `berat_bersih`, `harga_komp`, `harga_beli`) VALUES
	('PB-210221-0001', 1, 'MT', 'CCMT', 'cc mt 1', 1.2, 1.2, 480000, 480000),
	('PB-210221-0002', 1, 'MT', 'KLMT', 'kl mt 1', 3.9, 3.9, 1560000, 1560000);
/*!40000 ALTER TABLE `tt_pembelian_detail` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_pembelian_head
CREATE TABLE IF NOT EXISTS `tt_pembelian_head` (
  `no_pembelian` varchar(50) NOT NULL,
  `tgl_pembelian` datetime DEFAULT NULL,
  `kode_sales` varchar(50) DEFAULT NULL,
  `kode_pelanggan` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `no_telp` varchar(50) DEFAULT NULL,
  `total_berat_kotor` double DEFAULT NULL,
  `total_berat_bersih` double DEFAULT NULL,
  `total_pembelian` double DEFAULT NULL,
  `catatan` varchar(500) DEFAULT NULL,
  `kode_user` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `tgl_batal` datetime DEFAULT NULL,
  `user_batal` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_pembelian`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table tokoemas.tt_pembelian_head: ~0 rows (approximately)
DELETE FROM `tt_pembelian_head`;
/*!40000 ALTER TABLE `tt_pembelian_head` DISABLE KEYS */;
INSERT INTO `tt_pembelian_head` (`no_pembelian`, `tgl_pembelian`, `kode_sales`, `kode_pelanggan`, `nama`, `alamat`, `no_telp`, `total_berat_kotor`, `total_berat_bersih`, `total_pembelian`, `catatan`, `kode_user`, `status`, `tgl_batal`, `user_batal`) VALUES
	('PB-210221-0001', '2021-02-21 08:42:50', 'Luluk', '', '', '', '', 1.2, 1.2, 480000, '', 'user', 'false', '2021-02-21 09:18:22', 'user'),
	('PB-210221-0002', '2021-02-21 08:42:56', 'Nurul', '', '', '', '', 3.9, 3.9, 1560000, '', 'user', 'true', '2000-01-01 00:00:00', '');
/*!40000 ALTER TABLE `tt_pembelian_head` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_penjualan_detail
CREATE TABLE IF NOT EXISTS `tt_penjualan_detail` (
  `no_penjualan` varchar(50) NOT NULL,
  `kode_barcode` varchar(50) NOT NULL,
  `kode_kategori` varchar(50) DEFAULT NULL,
  `kode_jenis` varchar(50) DEFAULT NULL,
  `nama_barang` varchar(50) DEFAULT NULL,
  `berat` double DEFAULT NULL,
  `nilai_pokok` double NOT NULL,
  `harga_komp` double NOT NULL,
  `harga_jual` double NOT NULL,
  `no_pembelian` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_penjualan`,`kode_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tt_penjualan_detail: ~0 rows (approximately)
DELETE FROM `tt_penjualan_detail`;
/*!40000 ALTER TABLE `tt_penjualan_detail` DISABLE KEYS */;
INSERT INTO `tt_penjualan_detail` (`no_penjualan`, `kode_barcode`, `kode_kategori`, `kode_jenis`, `nama_barang`, `berat`, `nilai_pokok`, `harga_komp`, `harga_jual`, `no_pembelian`) VALUES
	('PJ-210221-0001', '10000001', 'MT', 'CCMT', 'cc mt 1', 1.2, 480000, 540000, 540000, ''),
	('PJ-210221-0001', '10000004', 'MT', 'KLMT', 'kl mt 2', 4.1, 1640000, 1845000, 1845000, ''),
	('PJ-210221-0002', '10000002', 'MT', 'CCMT', 'cc mt 2', 1.8, 720000, 810000, 810000, ''),
	('PJ-210221-0003', '10000003', 'MT', 'KLMT', 'kl mt 1', 3.9, 1560000, 1755000, 1755000, '');
/*!40000 ALTER TABLE `tt_penjualan_detail` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_penjualan_head
CREATE TABLE IF NOT EXISTS `tt_penjualan_head` (
  `no_penjualan` varchar(50) NOT NULL,
  `tgl_penjualan` datetime DEFAULT NULL,
  `kode_sales` varchar(50) DEFAULT NULL,
  `kode_pelanggan` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `no_telp` varchar(50) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `grandtotal` double DEFAULT NULL,
  `catatan` varchar(500) DEFAULT NULL,
  `kode_user` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `tgl_batal` datetime DEFAULT NULL,
  `user_batal` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_penjualan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table tokoemas.tt_penjualan_head: ~0 rows (approximately)
DELETE FROM `tt_penjualan_head`;
/*!40000 ALTER TABLE `tt_penjualan_head` DISABLE KEYS */;
INSERT INTO `tt_penjualan_head` (`no_penjualan`, `tgl_penjualan`, `kode_sales`, `kode_pelanggan`, `nama`, `alamat`, `no_telp`, `total_berat`, `grandtotal`, `catatan`, `kode_user`, `status`, `tgl_batal`, `user_batal`) VALUES
	('PJ-210221-0001', '2021-02-21 08:42:07', 'Dwi', '', '', '', '', 5.3, 2385000, '', 'user', 'true', '2000-01-01 00:00:00', ''),
	('PJ-210221-0002', '2021-02-21 08:42:20', 'Fera', '', '', '', '', 1.8, 810000, '', 'user', 'true', '2000-01-01 00:00:00', ''),
	('PJ-210221-0003', '2021-02-21 08:42:27', 'Luluk', '', '', '', '', 3.9, 1755000, '', 'user', 'true', '2000-01-01 00:00:00', '');
/*!40000 ALTER TABLE `tt_penjualan_head` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_pindah_detail
CREATE TABLE IF NOT EXISTS `tt_pindah_detail` (
  `no_pindah` varchar(50) NOT NULL,
  `kode_barcode` varchar(50) NOT NULL,
  `gudang_asal` varchar(50) NOT NULL,
  PRIMARY KEY (`no_pindah`,`kode_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_pindah_detail: ~1 rows (approximately)
DELETE FROM `tt_pindah_detail`;
/*!40000 ALTER TABLE `tt_pindah_detail` DISABLE KEYS */;
INSERT INTO `tt_pindah_detail` (`no_pindah`, `kode_barcode`, `gudang_asal`) VALUES
	('PB-190318-0001', '00000001', ''),
	('PB-210221-0001', '10000001', 'BAKI BARCODE'),
	('PB-210221-0001', '10000002', 'BAKI BARCODE'),
	('PB-210221-0001', '10000003', 'BAKI BARCODE'),
	('PB-210221-0001', '10000004', 'BAKI BARCODE');
/*!40000 ALTER TABLE `tt_pindah_detail` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_pindah_head
CREATE TABLE IF NOT EXISTS `tt_pindah_head` (
  `no_pindah` varchar(50) NOT NULL,
  `tgl_pindah` datetime DEFAULT NULL,
  `gudang_tujuan` varchar(50) DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `total_berat_asli` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_pindah`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_pindah_head: ~1 rows (approximately)
DELETE FROM `tt_pindah_head`;
/*!40000 ALTER TABLE `tt_pindah_head` DISABLE KEYS */;
INSERT INTO `tt_pindah_head` (`no_pindah`, `tgl_pindah`, `gudang_tujuan`, `total_qty`, `total_berat`, `total_berat_asli`, `kode_user`) VALUES
	('PB-190318-0001', '2019-03-18 07:23:40', NULL, 1, 1, 1, 'Fera'),
	('PB-210221-0001', '2021-02-21 08:41:04', 'NP01', 4, 11, 11, 'user');
/*!40000 ALTER TABLE `tt_pindah_head` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_servis
CREATE TABLE IF NOT EXISTS `tt_servis` (
  `no_servis` varchar(50) NOT NULL,
  `tgl_servis` datetime DEFAULT NULL,
  `kode_sales` varchar(50) DEFAULT NULL,
  `kode_pelanggan` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `no_telp` varchar(50) DEFAULT NULL,
  `nama_barang` varchar(50) DEFAULT NULL,
  `berat` double DEFAULT NULL,
  `kategori_servis` varchar(50) DEFAULT NULL,
  `biaya_servis` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `tgl_ambil` date DEFAULT NULL,
  `sales_ambil` varchar(50) DEFAULT NULL,
  `tgl_batal` date DEFAULT NULL,
  `sales_batal` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_servis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tt_servis: ~0 rows (approximately)
DELETE FROM `tt_servis`;
/*!40000 ALTER TABLE `tt_servis` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_servis` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_stok_barang
CREATE TABLE IF NOT EXISTS `tt_stok_barang` (
  `tanggal` date NOT NULL,
  `kode_barcode` varchar(20) NOT NULL,
  `kode_kategori` varchar(20) NOT NULL,
  `kode_jenis` varchar(20) NOT NULL,
  `kode_gudang` varchar(20) NOT NULL,
  `berat_awal` double DEFAULT '0',
  `berat_asli_awal` double DEFAULT '0',
  `stok_awal` int(11) DEFAULT '0',
  `berat_masuk` double DEFAULT '0',
  `berat_asli_masuk` double DEFAULT '0',
  `stok_masuk` int(11) DEFAULT '0',
  `berat_keluar` double DEFAULT '0',
  `berat_asli_keluar` double DEFAULT '0',
  `stok_keluar` int(11) DEFAULT '0',
  `berat_akhir` double DEFAULT '0',
  `berat_asli_akhir` double DEFAULT '0',
  `stok_akhir` int(11) DEFAULT '0',
  PRIMARY KEY (`tanggal`,`kode_barcode`,`kode_jenis`,`kode_gudang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table tokoemas.tt_stok_barang: ~0 rows (approximately)
DELETE FROM `tt_stok_barang`;
/*!40000 ALTER TABLE `tt_stok_barang` DISABLE KEYS */;
INSERT INTO `tt_stok_barang` (`tanggal`, `kode_barcode`, `kode_kategori`, `kode_jenis`, `kode_gudang`, `berat_awal`, `berat_asli_awal`, `stok_awal`, `berat_masuk`, `berat_asli_masuk`, `stok_masuk`, `berat_keluar`, `berat_asli_keluar`, `stok_keluar`, `berat_akhir`, `berat_asli_akhir`, `stok_akhir`) VALUES
	('2021-02-21', '', 'MT', 'CCMT', '', 0, 0, 0, 3, 3, 2, 3, 3, 2, 0, 0, 0),
	('2021-02-21', '', 'MT', 'KLMT', '', 0, 0, 0, 12, 12, 3, 12, 12, 3, 0, 0, 0),
	('2021-02-21', '10000001', 'MT', 'CCMT', 'BAKI BARCODE', 0, 0, 0, 1.2, 1.2, 1, 1.2, 1.2, 1, 0, 0, 0),
	('2021-02-21', '10000001', 'MT', 'CCMT', 'NP01', 0, 0, 0, 1.2, 1.2, 1, 1.2, 1.2, 1, 0, 0, 0),
	('2021-02-21', '10000002', 'MT', 'CCMT', 'BAKI BARCODE', 0, 0, 0, 1.8, 1.8, 1, 1.8, 1.8, 1, 0, 0, 0),
	('2021-02-21', '10000002', 'MT', 'CCMT', 'NP01', 0, 0, 0, 1.8, 1.8, 1, 1.8, 1.8, 1, 0, 0, 0),
	('2021-02-21', '10000003', 'MT', 'KLMT', 'BAKI BARCODE', 0, 0, 0, 3.9, 3.9, 1, 3.9, 3.9, 1, 0, 0, 0),
	('2021-02-21', '10000003', 'MT', 'KLMT', 'NP01', 0, 0, 0, 3.9, 3.9, 1, 3.9, 3.9, 1, 0, 0, 0),
	('2021-02-21', '10000004', 'MT', 'KLMT', 'BAKI BARCODE', 0, 0, 0, 4.1, 4.1, 1, 4.1, 4.1, 1, 0, 0, 0),
	('2021-02-21', '10000004', 'MT', 'KLMT', 'NP01', 0, 0, 0, 4.1, 4.1, 1, 4.1, 4.1, 1, 0, 0, 0),
	('2021-02-21', '10000005', 'MT', 'KLMT', 'BAKI BARCODE', 0, 0, 0, 4, 4, 1, 4, 4, 1, 0, 0, 0);
/*!40000 ALTER TABLE `tt_stok_barang` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_stok_opname_detail
CREATE TABLE IF NOT EXISTS `tt_stok_opname_detail` (
  `no_stok_opname` varchar(50) NOT NULL,
  `kode_barcode` varchar(50) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_stok_opname`,`kode_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tt_stok_opname_detail: ~5 rows (approximately)
DELETE FROM `tt_stok_opname_detail`;
/*!40000 ALTER TABLE `tt_stok_opname_detail` DISABLE KEYS */;
INSERT INTO `tt_stok_opname_detail` (`no_stok_opname`, `kode_barcode`, `status`, `kode_user`) VALUES
	('SO-210220-0001', '00000002', 'false', ''),
	('SO-210220-0001', '00000003', 'false', ''),
	('SO-210220-0001', '00000004', 'false', ''),
	('SO-210220-0001', '00000005', 'false', ''),
	('SO-210220-0001', '00000006', 'false', '');
/*!40000 ALTER TABLE `tt_stok_opname_detail` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_stok_opname_head
CREATE TABLE IF NOT EXISTS `tt_stok_opname_head` (
  `no_stok_opname` varchar(50) NOT NULL,
  `tgl_stok_opname` datetime DEFAULT NULL,
  `kode_gudang` varchar(50) DEFAULT NULL,
  `kode_kategori` varchar(50) DEFAULT NULL,
  `kode_jenis` varchar(50) DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  PRIMARY KEY (`no_stok_opname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tt_stok_opname_head: ~2 rows (approximately)
DELETE FROM `tt_stok_opname_head`;
/*!40000 ALTER TABLE `tt_stok_opname_head` DISABLE KEYS */;
INSERT INTO `tt_stok_opname_head` (`no_stok_opname`, `tgl_stok_opname`, `kode_gudang`, `kode_kategori`, `kode_jenis`, `total_qty`, `total_berat`) VALUES
	('SO-190617-0001', '2019-06-17 04:43:39', 'Semua', 'MDS', 'Semua', 0, 0),
	('SO-210220-0001', '2021-02-21 00:01:17', 'Semua', 'Semua', 'Semua', 0, 0);
/*!40000 ALTER TABLE `tt_stok_opname_head` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_tambah_barang_detail
CREATE TABLE IF NOT EXISTS `tt_tambah_barang_detail` (
  `no_tambah` varchar(50) NOT NULL,
  `no_urut` int(11) NOT NULL,
  `kode_kategori` varchar(50) DEFAULT NULL,
  `kode_jenis` varchar(50) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `berat` double DEFAULT NULL,
  PRIMARY KEY (`no_tambah`,`no_urut`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_tambah_barang_detail: ~2 rows (approximately)
DELETE FROM `tt_tambah_barang_detail`;
/*!40000 ALTER TABLE `tt_tambah_barang_detail` DISABLE KEYS */;
INSERT INTO `tt_tambah_barang_detail` (`no_tambah`, `no_urut`, `kode_kategori`, `kode_jenis`, `qty`, `berat`) VALUES
	('TB-190318-0001', 0, 'MD', 'ATMD', 1, 1),
	('TB-210215-0001', 0, 'MD', 'ATMD', 1, 5),
	('TB-210221-0001', 1, 'MT', 'CCMT', 2, 3),
	('TB-210221-0001', 2, 'MT', 'KLMT', 3, 12);
/*!40000 ALTER TABLE `tt_tambah_barang_detail` ENABLE KEYS */;


-- Dumping structure for table tokoemas.tt_tambah_barang_head
CREATE TABLE IF NOT EXISTS `tt_tambah_barang_head` (
  `no_tambah` varchar(50) NOT NULL,
  `tgl_tambah` datetime DEFAULT NULL,
  `keterangan` varchar(50) DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_tambah`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_tambah_barang_head: ~2 rows (approximately)
DELETE FROM `tt_tambah_barang_head`;
/*!40000 ALTER TABLE `tt_tambah_barang_head` DISABLE KEYS */;
INSERT INTO `tt_tambah_barang_head` (`no_tambah`, `tgl_tambah`, `keterangan`, `total_qty`, `total_berat`, `kode_user`) VALUES
	('TB-190318-0001', '2019-03-18 07:22:56', '', 1, 1, 'user'),
	('TB-210215-0001', '2021-02-15 23:14:24', '', 1, 5, 'user'),
	('TB-210221-0001', '2021-02-21 08:32:37', '', 5, 15, 'user');
/*!40000 ALTER TABLE `tt_tambah_barang_head` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
