-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.15-log - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for tokoemas
CREATE DATABASE IF NOT EXISTS `tokoemas` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `tokoemas`;

-- Dumping structure for table tokoemas.tm_barang
CREATE TABLE IF NOT EXISTS `tm_barang` (
  `kode_barcode` varchar(8) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  `kode_kategori` varchar(50) NOT NULL,
  `kode_jenis` varchar(50) NOT NULL,
  `kode_gudang` varchar(20) NOT NULL,
  `kode_intern` varchar(20) NOT NULL,
  `kadar` varchar(20) NOT NULL,
  `berat` double NOT NULL,
  `berat_asli` double NOT NULL,
  `nilai_pokok` double NOT NULL,
  `harga_jual` double NOT NULL,
  `status_barang` varchar(30) NOT NULL,
  `barcode_date` datetime NOT NULL,
  `barcode_by` varchar(20) NOT NULL,
  `deleted_date` datetime NOT NULL,
  `deleted_by` varchar(20) NOT NULL,
  `sold_date` datetime NOT NULL,
  `sold_by` varchar(20) NOT NULL,
  PRIMARY KEY (`kode_barcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table tokoemas.tm_barang: ~0 rows (approximately)
DELETE FROM `tm_barang`;
/*!40000 ALTER TABLE `tm_barang` DISABLE KEYS */;
/*!40000 ALTER TABLE `tm_barang` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tm_bunga_gadai
CREATE TABLE IF NOT EXISTS `tm_bunga_gadai` (
  `value_min` double NOT NULL,
  `value_max` double NOT NULL,
  `bunga` double DEFAULT NULL,
  PRIMARY KEY (`value_min`,`value_max`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_bunga_gadai: ~4 rows (approximately)
DELETE FROM `tm_bunga_gadai`;
/*!40000 ALTER TABLE `tm_bunga_gadai` DISABLE KEYS */;
INSERT INTO `tm_bunga_gadai` (`value_min`, `value_max`, `bunga`) VALUES
	(0, 500000, 4),
	(500001, 5000000, 3),
	(5000001, 10000000, 2.5),
	(10000001, 100000000, 2);
/*!40000 ALTER TABLE `tm_bunga_gadai` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tm_gadai_detail
CREATE TABLE IF NOT EXISTS `tm_gadai_detail` (
  `no_gadai` varchar(50) DEFAULT NULL,
  `kode_kategori` varchar(50) DEFAULT NULL,
  `nama_barang` varchar(50) DEFAULT NULL,
  `berat` double DEFAULT NULL,
  `nilai_jual` double DEFAULT NULL,
  `nilai_jual_sekarang` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_gadai_detail: ~0 rows (approximately)
DELETE FROM `tm_gadai_detail`;
/*!40000 ALTER TABLE `tm_gadai_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tm_gadai_detail` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tm_gadai_head
CREATE TABLE IF NOT EXISTS `tm_gadai_head` (
  `no_gadai` varchar(50) NOT NULL DEFAULT '',
  `tgl_gadai` datetime DEFAULT NULL,
  `kode_sales` varchar(50) DEFAULT NULL,
  `kode_pelanggan` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `no_telp` varchar(50) DEFAULT NULL,
  `keterangan` varchar(500) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `total_pinjaman` double DEFAULT NULL,
  `lama_pinjam` int(11) DEFAULT NULL,
  `bunga_persen` double DEFAULT NULL,
  `bunga_komp` double DEFAULT NULL,
  `bunga_rp` double DEFAULT NULL,
  `jatuh_tempo` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `tgl_lunas` datetime DEFAULT NULL,
  `sales_lunas` varchar(50) DEFAULT NULL,
  `tgl_batal` datetime DEFAULT NULL,
  `sales_batal` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_gadai`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table tokoemas.tm_gadai_head: ~0 rows (approximately)
DELETE FROM `tm_gadai_head`;
/*!40000 ALTER TABLE `tm_gadai_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `tm_gadai_head` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tm_gudang
CREATE TABLE IF NOT EXISTS `tm_gudang` (
  `kode_gudang` varchar(50) DEFAULT NULL,
  `berat_baki` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_gudang: ~37 rows (approximately)
DELETE FROM `tm_gudang`;
/*!40000 ALTER TABLE `tm_gudang` DISABLE KEYS */;
INSERT INTO `tm_gudang` (`kode_gudang`, `berat_baki`) VALUES
	('BAKI BARCODE', '0.0'),
	('NP02', '368.05'),
	('BAKI BARCODE 2', '0.0'),
	('BAKI BARCODE 3', '0.0'),
	('NP01', '397.69'),
	('NP03', '384.14'),
	('NP04', '369.18'),
	('NP05', '717.87'),
	('NP06', '375.0'),
	('NP07', '379.34'),
	('NP08', '310.23'),
	('NP09', '386.1'),
	('NP10', '842.7'),
	('NP11', '407.2'),
	('NP13', '428.3'),
	('NP12', '410.8'),
	('NP14', '410.8'),
	('PTSK19', '58.03'),
	('PTSK22', '96.75'),
	('PTSK26', '61.62'),
	('PTSK20', '220.14'),
	('PTSK30', '101.86'),
	('PTSK31', '63.43'),
	('PTSK33', '72.14'),
	('NP15', '100.34'),
	('NP18', '101.9'),
	('NP23', '98.98'),
	('NP17', '74.5'),
	('NP24', '326.79'),
	('NP25', '302.52'),
	('NP28', '70.09'),
	('NP31', '60.87'),
	('NP21', '227.51'),
	('NP19', '57.36'),
	('NP20', '220.05'),
	('NP27', '146.3'),
	('NP34', '88.56');
/*!40000 ALTER TABLE `tm_gudang` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tm_jenis
CREATE TABLE IF NOT EXISTS `tm_jenis` (
  `kode_jenis` varchar(20) NOT NULL,
  `nama_jenis` varchar(50) NOT NULL,
  `kode_kategori` varchar(20) NOT NULL,
  PRIMARY KEY (`kode_jenis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_jenis: ~22 rows (approximately)
DELETE FROM `tm_jenis`;
/*!40000 ALTER TABLE `tm_jenis` DISABLE KEYS */;
INSERT INTO `tm_jenis` (`kode_jenis`, `nama_jenis`, `kode_kategori`) VALUES
	('ATMD', 'anting md', 'MD'),
	('ATMDS', 'anting mds', 'MDS'),
	('ATMT', 'anting mt', 'MT'),
	('CCINTEN', 'cincin inten', 'INTEN'),
	('CCMD', 'cincin md', 'MD'),
	('CCMDS', 'cincin mds', 'MDS'),
	('CCMT', 'cincin mt', 'MT'),
	('GLINTEN', 'gelang inten', 'INTEN'),
	('GLMD', 'gelang md', 'MD'),
	('GLMDS', 'gelang mds', 'MDS'),
	('GLMT', 'gelang mt', 'MT'),
	('KLMD', 'kalung md', 'MD'),
	('KLMDS', 'kalung mds', 'MDS'),
	('KLMT', 'kalung mt', 'MT'),
	('MNINTEN', 'mainan inten', 'INTEN'),
	('MNMD', 'mainan md', 'MD'),
	('MNMDS', 'mainan mds', 'MDS'),
	('MNMT', 'mainan mt', 'MT'),
	('TDINTEN', 'tindik inten', 'INTEN'),
	('TDMD', 'tindik md', 'MD'),
	('TDMDS', 'tindik mds', 'MDS'),
	('TDMT', 'tindik mt', 'MT');
/*!40000 ALTER TABLE `tm_jenis` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tm_kategori
CREATE TABLE IF NOT EXISTS `tm_kategori` (
  `kode_kategori` varchar(20) NOT NULL,
  `nama_kategori` varchar(50) NOT NULL,
  `harga_beli` double NOT NULL,
  `harga_jual` double NOT NULL,
  PRIMARY KEY (`kode_kategori`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table tokoemas.tm_kategori: ~7 rows (approximately)
DELETE FROM `tm_kategori`;
/*!40000 ALTER TABLE `tm_kategori` DISABLE KEYS */;
INSERT INTO `tm_kategori` (`kode_kategori`, `nama_kategori`, `harga_beli`, `harga_jual`) VALUES
	('INTEN', 'inten md', 200000, 500000),
	('MD', 'emas muda', 190000, 210000),
	('MDS', 'emas tengahan', 260000, 270000),
	('MT', 'emas tua', 400000, 450000),
	('MT87', 'MT87', 450000, 525000),
	('MT916', 'MT916', 550000, 650000),
	('MT99', 'MT99', 575000, 675000);
/*!40000 ALTER TABLE `tm_kategori` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tm_kategori_transaksi
CREATE TABLE IF NOT EXISTS `tm_kategori_transaksi` (
  `kode_kategori` varchar(50) NOT NULL,
  `jenis_transaksi` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`kode_kategori`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_kategori_transaksi: ~5 rows (approximately)
DELETE FROM `tm_kategori_transaksi`;
/*!40000 ALTER TABLE `tm_kategori_transaksi` DISABLE KEYS */;
INSERT INTO `tm_kategori_transaksi` (`kode_kategori`, `jenis_transaksi`) VALUES
	('BEBAN GAJI', 'K'),
	('BEBAN OPERASIONAL', 'K'),
	('PEMBELIAN SUPPLIER', 'K'),
	('PENDAPATAN LAIN-LAIN', 'D'),
	('TAMBAH MODAL', 'D');
/*!40000 ALTER TABLE `tm_kategori_transaksi` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tm_log_harga
CREATE TABLE IF NOT EXISTS `tm_log_harga` (
  `tanggal` datetime NOT NULL,
  `kode_kategori` varchar(20) NOT NULL,
  `harga_beli` double NOT NULL,
  `harga_jual` double NOT NULL,
  `user` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_log_harga: ~0 rows (approximately)
DELETE FROM `tm_log_harga`;
/*!40000 ALTER TABLE `tm_log_harga` DISABLE KEYS */;
/*!40000 ALTER TABLE `tm_log_harga` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tm_otoritas
CREATE TABLE IF NOT EXISTS `tm_otoritas` (
  `username` varchar(50) NOT NULL,
  `jenis` varchar(50) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`username`,`jenis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_otoritas: ~46 rows (approximately)
DELETE FROM `tm_otoritas`;
/*!40000 ALTER TABLE `tm_otoritas` DISABLE KEYS */;
INSERT INTO `tm_otoritas` (`username`, `jenis`, `status`) VALUES
	('kasir', 'Ambil Barang', 'false'),
	('kasir', 'Barcode Barang', 'false'),
	('kasir', 'Data Pelanggan', 'true'),
	('kasir', 'Data Pelunasan Gadai', 'false'),
	('kasir', 'Data Pembelian', 'true'),
	('kasir', 'Data Penjualan', 'true'),
	('kasir', 'Data Sales', 'false'),
	('kasir', 'Data Terima Gadai', 'true'),
	('kasir', 'Detail Barang Barcode', 'false'),
	('kasir', 'Keuangan', 'false'),
	('kasir', 'Laporan Barang', 'false'),
	('kasir', 'Laporan Gadai', 'false'),
	('kasir', 'Laporan Keuangan', 'false'),
	('kasir', 'Laporan Pembelian', 'false'),
	('kasir', 'Laporan Penjualan', 'false'),
	('kasir', 'Pelunasan Gadai', 'false'),
	('kasir', 'Pembelian Baru', 'true'),
	('kasir', 'Pengaturan Umum', 'false'),
	('kasir', 'Penjualan Baru', 'true'),
	('kasir', 'Stok Barang Barcode', 'false'),
	('kasir', 'Stok Barang Dalam', 'false'),
	('kasir', 'Tambah Barang', 'false'),
	('kasir', 'Terima Gadai', 'true'),
	('user', 'Ambil Barang', 'true'),
	('user', 'Barcode Barang', 'true'),
	('user', 'Data Pelanggan', 'true'),
	('user', 'Data Pelunasan Gadai', 'true'),
	('user', 'Data Pembelian', 'true'),
	('user', 'Data Penjualan', 'true'),
	('user', 'Data Sales', 'true'),
	('user', 'Data Terima Gadai', 'true'),
	('user', 'Detail Barang Barcode', 'true'),
	('user', 'Keuangan', 'true'),
	('user', 'Laporan Barang', 'true'),
	('user', 'Laporan Gadai', 'true'),
	('user', 'Laporan Keuangan', 'true'),
	('user', 'Laporan Pembelian', 'true'),
	('user', 'Laporan Penjualan', 'true'),
	('user', 'Pelunasan Gadai', 'true'),
	('user', 'Pembelian Baru', 'true'),
	('user', 'Pengaturan Umum', 'true'),
	('user', 'Penjualan Baru', 'true'),
	('user', 'Stok Barang Barcode', 'true'),
	('user', 'Stok Barang Dalam', 'true'),
	('user', 'Tambah Barang', 'true'),
	('user', 'Terima Gadai', 'true');
/*!40000 ALTER TABLE `tm_otoritas` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tm_pelanggan
CREATE TABLE IF NOT EXISTS `tm_pelanggan` (
  `kode_pelanggan` varchar(50) NOT NULL,
  `nama` varchar(20) DEFAULT NULL,
  `alamat` varchar(20) DEFAULT NULL,
  `no_telp` varchar(20) DEFAULT NULL,
  `no_handphone` varchar(50) DEFAULT NULL,
  `keterangan` varchar(500) DEFAULT NULL,
  `identitas` varchar(50) DEFAULT NULL,
  `no_identitas` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`kode_pelanggan`),
  UNIQUE KEY `Index 2` (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_pelanggan: ~0 rows (approximately)
DELETE FROM `tm_pelanggan`;
/*!40000 ALTER TABLE `tm_pelanggan` DISABLE KEYS */;
/*!40000 ALTER TABLE `tm_pelanggan` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tm_sales
CREATE TABLE IF NOT EXISTS `tm_sales` (
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(500) DEFAULT NULL,
  `no_telp` varchar(50) DEFAULT NULL,
  `no_handphone` varchar(50) DEFAULT NULL,
  `keterangan` varchar(50) DEFAULT NULL,
  `identitas` varchar(50) DEFAULT NULL,
  `no_identitas` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`nama`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_sales: ~5 rows (approximately)
DELETE FROM `tm_sales`;
/*!40000 ALTER TABLE `tm_sales` DISABLE KEYS */;
INSERT INTO `tm_sales` (`nama`, `alamat`, `no_telp`, `no_handphone`, `keterangan`, `identitas`, `no_identitas`, `status`) VALUES
	('Dwi', '', '', '', '', '', '', 'true'),
	('Fera', '', '', '', '', '', '', 'true'),
	('Luluk', '', '', '', '', '', '', 'true'),
	('Murni', '', '', '', '', '', '', 'true'),
	('Nurul', '', '', '', '', '', '', 'true');
/*!40000 ALTER TABLE `tm_sales` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tm_system
CREATE TABLE IF NOT EXISTS `tm_system` (
  `nama` varchar(50) DEFAULT NULL,
  `alamat` varchar(40) DEFAULT NULL,
  `kota` varchar(10) DEFAULT NULL,
  `no_telp` varchar(40) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `berat_label` double DEFAULT NULL,
  `tgl_system` date DEFAULT NULL,
  `persentase_pinjaman` double DEFAULT NULL,
  `jatuh_tempo` int(11) DEFAULT NULL,
  `code` varchar(1) DEFAULT NULL,
  `printer_penjualan` varchar(50) DEFAULT NULL,
  `printer_gadai` varchar(50) DEFAULT NULL,
  `printer_barcode` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tm_system: ~1 rows (approximately)
DELETE FROM `tm_system`;
/*!40000 ALTER TABLE `tm_system` DISABLE KEYS */;
INSERT INTO `tm_system` (`nama`, `alamat`, `kota`, `no_telp`, `email`, `berat_label`, `tgl_system`, `persentase_pinjaman`, `jatuh_tempo`, `code`, `printer_penjualan`, `printer_gadai`, `printer_barcode`) VALUES
	('Toko Emas Rajawali', 'Pasar Ungaran No. 6', 'Ungaran', '', '', 0.05, '2019-02-12', 70, 90, '0', 'EPSON LX-310', 'EPSON TM-U220', 'SATO CG 408TT');
/*!40000 ALTER TABLE `tm_system` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tm_user
CREATE TABLE IF NOT EXISTS `tm_user` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `level` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_user: ~2 rows (approximately)
DELETE FROM `tm_user`;
/*!40000 ALTER TABLE `tm_user` DISABLE KEYS */;
INSERT INTO `tm_user` (`username`, `password`, `level`) VALUES
	('kasir', 'kasir', 'Sales'),
	('user', 'user', 'Admin');
/*!40000 ALTER TABLE `tm_user` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tm_verifikasi
CREATE TABLE IF NOT EXISTS `tm_verifikasi` (
  `username` varchar(50) DEFAULT NULL,
  `jenis` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tm_verifikasi: ~30 rows (approximately)
DELETE FROM `tm_verifikasi`;
/*!40000 ALTER TABLE `tm_verifikasi` DISABLE KEYS */;
INSERT INTO `tm_verifikasi` (`username`, `jenis`, `status`) VALUES
	('kasir', 'Tambah Barang', 'false'),
	('kasir', 'Ambil Barang', 'false'),
	('kasir', 'Hancur Barang', 'false'),
	('kasir', 'Penjualan', 'false'),
	('kasir', 'Batal Penjualan', 'false'),
	('kasir', 'Pembelian', 'false'),
	('kasir', 'Batal Pembelian', 'false'),
	('kasir', 'Ubah Berat Gadai', 'false'),
	('kasir', 'Terima Gadai', 'false'),
	('kasir', 'Batal Terima Gadai', 'false'),
	('kasir', 'Pelunasan Gadai', 'false'),
	('kasir', 'Batal Pelunasan Gadai', 'false'),
	('kasir', 'Batal Keuangan', 'false'),
	('user', 'Tambah Barang', 'true'),
	('user', 'Ambil Barang', 'true'),
	('user', 'Hancur Barang', 'true'),
	('user', 'Import Barang', 'true'),
	('user', 'Export Barang', 'true'),
	('user', 'Penjualan', 'true'),
	('user', 'Batal Penjualan', 'true'),
	('user', 'Pembelian', 'true'),
	('user', 'Batal Pembelian', 'true'),
	('user', 'Ubah Berat Gadai', 'true'),
	('user', 'Terima Gadai', 'true'),
	('user', 'Batal Terima Gadai', 'true'),
	('user', 'Pelunasan Gadai', 'true'),
	('user', 'Batal Pelunasan Gadai', 'true'),
	('user', 'Batal Keuangan', 'true'),
	('user', 'Import Barang', 'true'),
	('user', 'Edit Barang', 'true');
/*!40000 ALTER TABLE `tm_verifikasi` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_ambil_barang_detail
CREATE TABLE IF NOT EXISTS `tt_ambil_barang_detail` (
  `no_ambil` varchar(50) DEFAULT NULL,
  `kode_kategori` varchar(50) DEFAULT NULL,
  `kode_jenis` varchar(50) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `berat` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_ambil_barang_detail: ~0 rows (approximately)
DELETE FROM `tt_ambil_barang_detail`;
/*!40000 ALTER TABLE `tt_ambil_barang_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_ambil_barang_detail` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_ambil_barang_head
CREATE TABLE IF NOT EXISTS `tt_ambil_barang_head` (
  `no_ambil` varchar(50) DEFAULT NULL,
  `tgl_ambil` datetime DEFAULT NULL,
  `keterangan` varchar(50) DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_ambil_barang_head: ~0 rows (approximately)
DELETE FROM `tt_ambil_barang_head`;
/*!40000 ALTER TABLE `tt_ambil_barang_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_ambil_barang_head` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_cetak_barcode_detail
CREATE TABLE IF NOT EXISTS `tt_cetak_barcode_detail` (
  `no_cetak` varchar(50) DEFAULT NULL,
  `kode_barcode` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_cetak_barcode_detail: ~0 rows (approximately)
DELETE FROM `tt_cetak_barcode_detail`;
/*!40000 ALTER TABLE `tt_cetak_barcode_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_cetak_barcode_detail` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_cetak_barcode_head
CREATE TABLE IF NOT EXISTS `tt_cetak_barcode_head` (
  `no_cetak` varchar(50) DEFAULT NULL,
  `tgl_cetak` datetime DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `total_berat_asli` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `tgl_batal` datetime DEFAULT NULL,
  `user_batal` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_cetak_barcode_head: ~0 rows (approximately)
DELETE FROM `tt_cetak_barcode_head`;
/*!40000 ALTER TABLE `tt_cetak_barcode_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_cetak_barcode_head` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_export_detail
CREATE TABLE IF NOT EXISTS `tt_export_detail` (
  `no_export` varchar(50) DEFAULT NULL,
  `kode_barcode` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_export_detail: ~0 rows (approximately)
DELETE FROM `tt_export_detail`;
/*!40000 ALTER TABLE `tt_export_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_export_detail` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_export_head
CREATE TABLE IF NOT EXISTS `tt_export_head` (
  `no_export` varchar(50) DEFAULT NULL,
  `tgl_export` datetime DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `total_berat_asli` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_export_head: ~0 rows (approximately)
DELETE FROM `tt_export_head`;
/*!40000 ALTER TABLE `tt_export_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_export_head` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_hancur_detail
CREATE TABLE IF NOT EXISTS `tt_hancur_detail` (
  `no_hancur` varchar(50) DEFAULT NULL,
  `kode_barcode` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_hancur_detail: ~0 rows (approximately)
DELETE FROM `tt_hancur_detail`;
/*!40000 ALTER TABLE `tt_hancur_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_hancur_detail` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_hancur_head
CREATE TABLE IF NOT EXISTS `tt_hancur_head` (
  `no_hancur` varchar(50) DEFAULT NULL,
  `tgl_hancur` datetime DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `total_berat_asli` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_hancur_head: ~0 rows (approximately)
DELETE FROM `tt_hancur_head`;
/*!40000 ALTER TABLE `tt_hancur_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_hancur_head` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_import_detail
CREATE TABLE IF NOT EXISTS `tt_import_detail` (
  `no_import` varchar(50) DEFAULT NULL,
  `kode_barcode` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_import_detail: ~0 rows (approximately)
DELETE FROM `tt_import_detail`;
/*!40000 ALTER TABLE `tt_import_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_import_detail` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_import_head
CREATE TABLE IF NOT EXISTS `tt_import_head` (
  `no_import` varchar(50) DEFAULT NULL,
  `tgl_import` datetime DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `total_berat_asli` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_import_head: ~0 rows (approximately)
DELETE FROM `tt_import_head`;
/*!40000 ALTER TABLE `tt_import_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_import_head` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_keuangan
CREATE TABLE IF NOT EXISTS `tt_keuangan` (
  `no_keuangan` varchar(50) NOT NULL,
  `tgl_keuangan` datetime DEFAULT NULL,
  `tipe_transaksi` varchar(50) DEFAULT NULL,
  `kategori` varchar(50) DEFAULT NULL,
  `deskripsi` varchar(500) DEFAULT NULL,
  `jumlah_rp` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_keuangan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tt_keuangan: ~0 rows (approximately)
DELETE FROM `tt_keuangan`;
/*!40000 ALTER TABLE `tt_keuangan` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_keuangan` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_pembelian_detail
CREATE TABLE IF NOT EXISTS `tt_pembelian_detail` (
  `no_pembelian` varchar(50) DEFAULT NULL,
  `kode_jenis` varchar(50) DEFAULT NULL,
  `kode_kategori` varchar(50) DEFAULT NULL,
  `nama_barang` varchar(50) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `berat_kotor` double DEFAULT NULL,
  `berat_bersih` double DEFAULT NULL,
  `harga_komp` double DEFAULT NULL,
  `harga_beli` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tt_pembelian_detail: ~0 rows (approximately)
DELETE FROM `tt_pembelian_detail`;
/*!40000 ALTER TABLE `tt_pembelian_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_pembelian_detail` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_pembelian_head
CREATE TABLE IF NOT EXISTS `tt_pembelian_head` (
  `no_pembelian` varchar(50) NOT NULL,
  `tgl_pembelian` datetime DEFAULT NULL,
  `kode_sales` varchar(50) DEFAULT NULL,
  `kode_pelanggan` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `no_telp` varchar(50) DEFAULT NULL,
  `total_berat_kotor` double DEFAULT NULL,
  `total_berat_bersih` double DEFAULT NULL,
  `total_pembelian` double DEFAULT NULL,
  `catatan` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `tgl_batal` datetime DEFAULT NULL,
  `user_batal` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_pembelian`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table tokoemas.tt_pembelian_head: ~0 rows (approximately)
DELETE FROM `tt_pembelian_head`;
/*!40000 ALTER TABLE `tt_pembelian_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_pembelian_head` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_penjualan_detail
CREATE TABLE IF NOT EXISTS `tt_penjualan_detail` (
  `no_penjualan` varchar(50) NOT NULL,
  `kode_barcode` varchar(50) NOT NULL,
  `kode_kategori` varchar(50) DEFAULT NULL,
  `kode_jenis` varchar(50) DEFAULT NULL,
  `nama_barang` varchar(50) DEFAULT NULL,
  `berat` double DEFAULT NULL,
  `nilai_pokok` double NOT NULL,
  `harga_komp` double NOT NULL,
  `harga_jual` double NOT NULL,
  `ongkos` double DEFAULT NULL,
  `no_pembelian` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tt_penjualan_detail: ~0 rows (approximately)
DELETE FROM `tt_penjualan_detail`;
/*!40000 ALTER TABLE `tt_penjualan_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_penjualan_detail` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_penjualan_head
CREATE TABLE IF NOT EXISTS `tt_penjualan_head` (
  `no_penjualan` varchar(50) NOT NULL,
  `tgl_penjualan` datetime DEFAULT NULL,
  `kode_sales` varchar(50) DEFAULT NULL,
  `kode_pelanggan` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `no_telp` varchar(50) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `total_harga` double DEFAULT NULL,
  `total_ongkos` double DEFAULT NULL,
  `grandtotal` double DEFAULT NULL,
  `catatan` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `tgl_batal` datetime DEFAULT NULL,
  `user_batal` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_penjualan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table tokoemas.tt_penjualan_head: ~0 rows (approximately)
DELETE FROM `tt_penjualan_head`;
/*!40000 ALTER TABLE `tt_penjualan_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_penjualan_head` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_pindah_detail
CREATE TABLE IF NOT EXISTS `tt_pindah_detail` (
  `no_pindah` varchar(50) DEFAULT NULL,
  `kode_barcode` varchar(50) DEFAULT NULL,
  `gudang_asal` varchar(50) DEFAULT NULL,
  `gudang_tujuan` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_pindah_detail: ~0 rows (approximately)
DELETE FROM `tt_pindah_detail`;
/*!40000 ALTER TABLE `tt_pindah_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_pindah_detail` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_pindah_head
CREATE TABLE IF NOT EXISTS `tt_pindah_head` (
  `no_pindah` varchar(50) DEFAULT NULL,
  `tgl_pindah` datetime DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `total_berat_asli` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_pindah_head: ~0 rows (approximately)
DELETE FROM `tt_pindah_head`;
/*!40000 ALTER TABLE `tt_pindah_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_pindah_head` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_servis
CREATE TABLE IF NOT EXISTS `tt_servis` (
  `no_servis` varchar(50) NOT NULL,
  `tgl_servis` datetime DEFAULT NULL,
  `kode_sales` varchar(50) DEFAULT NULL,
  `kode_pelanggan` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `no_telp` varchar(50) DEFAULT NULL,
  `nama_barang` varchar(50) DEFAULT NULL,
  `berat` double DEFAULT NULL,
  `kategori_servis` varchar(50) DEFAULT NULL,
  `biaya_servis` double DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `tgl_ambil` date DEFAULT NULL,
  `sales_ambil` varchar(50) DEFAULT NULL,
  `tgl_batal` date DEFAULT NULL,
  `sales_batal` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`no_servis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tt_servis: ~0 rows (approximately)
DELETE FROM `tt_servis`;
/*!40000 ALTER TABLE `tt_servis` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_servis` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_stok_barang
CREATE TABLE IF NOT EXISTS `tt_stok_barang` (
  `tanggal` date NOT NULL,
  `kode_barcode` varchar(20) NOT NULL,
  `kode_kategori` varchar(20) NOT NULL,
  `kode_jenis` varchar(20) NOT NULL,
  `kode_gudang` varchar(20) NOT NULL,
  `berat_awal` double DEFAULT '0',
  `berat_asli_awal` double DEFAULT '0',
  `stok_awal` int(11) DEFAULT '0',
  `berat_masuk` double DEFAULT '0',
  `berat_asli_masuk` double DEFAULT '0',
  `stok_masuk` int(11) DEFAULT '0',
  `berat_keluar` double DEFAULT '0',
  `berat_asli_keluar` double DEFAULT '0',
  `stok_keluar` int(11) DEFAULT '0',
  `berat_akhir` double DEFAULT '0',
  `berat_asli_akhir` double DEFAULT '0',
  `stok_akhir` int(11) DEFAULT '0',
  PRIMARY KEY (`tanggal`,`kode_barcode`,`kode_jenis`,`kode_gudang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table tokoemas.tt_stok_barang: ~0 rows (approximately)
DELETE FROM `tt_stok_barang`;
/*!40000 ALTER TABLE `tt_stok_barang` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_stok_barang` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_stok_opname_detail
CREATE TABLE IF NOT EXISTS `tt_stok_opname_detail` (
  `no_stok_opname` varchar(50) DEFAULT NULL,
  `kode_barcode` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `kode_sales` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tt_stok_opname_detail: ~0 rows (approximately)
DELETE FROM `tt_stok_opname_detail`;
/*!40000 ALTER TABLE `tt_stok_opname_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_stok_opname_detail` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_stok_opname_head
CREATE TABLE IF NOT EXISTS `tt_stok_opname_head` (
  `no_stok_opname` varchar(50) NOT NULL,
  `tgl_stok_opname` datetime DEFAULT NULL,
  `kode_gudang` varchar(50) DEFAULT NULL,
  `kode_kategori` varchar(50) DEFAULT NULL,
  `kode_jenis` varchar(50) DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  PRIMARY KEY (`no_stok_opname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table tokoemas.tt_stok_opname_head: ~0 rows (approximately)
DELETE FROM `tt_stok_opname_head`;
/*!40000 ALTER TABLE `tt_stok_opname_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_stok_opname_head` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_tambah_barang_detail
CREATE TABLE IF NOT EXISTS `tt_tambah_barang_detail` (
  `no_tambah` varchar(50) DEFAULT NULL,
  `kode_kategori` varchar(50) DEFAULT NULL,
  `kode_jenis` varchar(50) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `berat` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_tambah_barang_detail: ~0 rows (approximately)
DELETE FROM `tt_tambah_barang_detail`;
/*!40000 ALTER TABLE `tt_tambah_barang_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_tambah_barang_detail` ENABLE KEYS */;

-- Dumping structure for table tokoemas.tt_tambah_barang_head
CREATE TABLE IF NOT EXISTS `tt_tambah_barang_head` (
  `no_tambah` varchar(50) DEFAULT NULL,
  `tgl_tambah` datetime DEFAULT NULL,
  `keterangan` varchar(50) DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_berat` double DEFAULT NULL,
  `kode_user` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table tokoemas.tt_tambah_barang_head: ~0 rows (approximately)
DELETE FROM `tt_tambah_barang_head`;
/*!40000 ALTER TABLE `tt_tambah_barang_head` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_tambah_barang_head` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
